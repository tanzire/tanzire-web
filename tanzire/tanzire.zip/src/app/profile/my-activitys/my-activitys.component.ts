import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-activitys',
  templateUrl: './my-activitys.component.html',
  styleUrls: ['./my-activitys.component.scss']
})
export class MyActivitysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
