import {  Route, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { NgModule } from '@angular/core';
import { HomePageAllComponent } from './home-page-all/home-page-all.component';
import { DashBoardPageComponent } from '../dashBoard/dash-board-page/dash-board-page.component';
import { DashBoardComponent } from '../dashBoard/dashBoard.component';
import { ProductsPageComponent } from '../products/products-page/products-page.component';
import { ProductRecommendationsComponent } from '../products/product-recommendations/product-recommendations.component';
import { ShopNowComponent } from '../products/shop-now/shop-now.component';
 const homeRoutes:Route[]=[
  //  {path:'',redirectTo:'home',pathMatch:'full'},
    {path:'', component:HomeComponent,
  children:[
    {path:'',component:HomePageAllComponent},
    {path:'dashboardpage' , component:DashBoardPageComponent,children:[
    {path:'',component:DashBoardComponent}]},

    {path:'productpage',component:ShopNowComponent},
    // {path:'recomandations',component: ProductRecommendationsComponent}
  ]}];
  

    @NgModule({
        imports: [RouterModule.forChild(homeRoutes)],
        exports: [RouterModule]
      })
      export class HomeRoutesModule { }