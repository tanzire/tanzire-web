import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page-all',
  templateUrl: './home-page-all.component.html',
  styleUrls: ['./home-page-all.component.scss']
})
export class HomePageAllComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
