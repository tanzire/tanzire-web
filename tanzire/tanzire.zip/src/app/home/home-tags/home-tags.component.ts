import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-tags',
  templateUrl: './home-tags.component.html',
  styleUrls: ['./home-tags.component.scss']
})
export class HomeTagsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
