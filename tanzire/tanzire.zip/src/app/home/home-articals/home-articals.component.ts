import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-articals',
  templateUrl: './home-articals.component.html',
  styleUrls: ['./home-articals.component.scss']
})
export class HomeArticalsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
