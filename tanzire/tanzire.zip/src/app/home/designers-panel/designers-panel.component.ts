import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-designers-panel',
  templateUrl: './designers-panel.component.html',
  styleUrls: ['./designers-panel.component.scss']
})
export class DesignersPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
