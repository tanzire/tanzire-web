import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-collections',
  templateUrl: './home-collections.component.html',
  styleUrls: ['./home-collections.component.scss']
})
export class HomeCollectionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
