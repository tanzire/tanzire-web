import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracking-orders',
  templateUrl: './tracking-orders.component.html',
  styleUrls: ['./tracking-orders.component.scss']
})
export class TrackingOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
