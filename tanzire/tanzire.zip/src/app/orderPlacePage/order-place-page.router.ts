import {  Route, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { OderPlacePageComponent } from './oder-place-page.component';
import { ShoppingBagComponent } from './shopping-bag/shopping-bag.component';
import { ShippingComponent } from './shipping/shipping.component';
import { TrackingOrdersComponent } from './tracking-orders/tracking-orders.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
 const orderRoutes:Route[]=[
    {path:'', component:OderPlacePageComponent,
children:[
    {path:'',redirectTo:'cartitem',pathMatch:'full'},
    {path:'cartitem',component:ShoppingBagComponent},
    {path:'shipping&Payment',component:ShippingComponent},
    {path:'trackingOrder',component:TrackingOrdersComponent},
    {path:'orderDetails',component:OrderDetailsComponent}
]
}];

    @NgModule({
        imports: [RouterModule.forChild(orderRoutes)],
        exports: [RouterModule]
      })
      export class OrderPlacePageRouterModule { }