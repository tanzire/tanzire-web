import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-placing',
  templateUrl: './order-placing.component.html',
  styleUrls: ['./order-placing.component.scss']
})
export class OrderPlacingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
