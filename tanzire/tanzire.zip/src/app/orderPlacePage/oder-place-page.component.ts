import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oder-place-page',
  templateUrl: './oder-place-page.component.html',
  styleUrls: ['./oder-place-page.component.scss']
})
export class OderPlacePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
