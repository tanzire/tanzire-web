import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShippingComponent } from './shipping/shipping.component';
import { CartComponent } from './cart/cart.component';
import { ShoppingBagComponent } from './shopping-bag/shopping-bag.component';
import { DashBoardModule } from '../dashBoard/dashBoard.module';
import { OderPlacePageComponent } from './oder-place-page.component';
import { OrderPlacingComponent } from './order-placing/order-placing.component';
import { TrackingOrdersComponent } from './tracking-orders/tracking-orders.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { ProductsPageModule } from '../products/products-page/products-page.module';
import { OrderPlacePageRouterModule } from './order-place-page.router';
import { ProductRecommendationsComponent } from '../products/product-recommendations/product-recommendations.component';
import { WishlistComponent } from '../dashBoard/wishlist/wishlist.component';

@NgModule({
  declarations: [ShippingComponent,
    CartComponent,
    ShoppingBagComponent,
     OderPlacePageComponent,
     OrderPlacingComponent,
     TrackingOrdersComponent,
     OrderDetailsComponent,
     ProductRecommendationsComponent,
     WishlistComponent
     
    ],
 
  imports: [
    CommonModule,
    OrderPlacePageRouterModule,

  ]
})
export class OrderPlacePageModule { }
