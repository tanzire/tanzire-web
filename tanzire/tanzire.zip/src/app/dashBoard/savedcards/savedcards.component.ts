import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-savedcards',
  templateUrl: './savedcards.component.html',
  styleUrls: ['./savedcards.component.scss']
})
export class SavedcardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
