import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loyaltypoints',
  templateUrl: './loyaltypoints.component.html',
  styleUrls: ['./loyaltypoints.component.scss']
})
export class LoyaltypointsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
