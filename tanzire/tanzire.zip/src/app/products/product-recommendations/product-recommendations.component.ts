import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-recommendations',
  templateUrl: './product-recommendations.component.html',
  styleUrls: ['./product-recommendations.component.scss']
})
export class ProductRecommendationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
