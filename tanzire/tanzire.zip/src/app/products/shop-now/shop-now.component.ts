import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-now',
  templateUrl: './shop-now.component.html',
  styleUrls: ['./shop-now.component.scss']
})
export class ShopNowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
